<HTML>
<HEAD>
<TITLE>PHP version check</TITLE>
</HEAD>
<BODY>
<?php phpinfo(); ?>
</BODY>
</HTML>