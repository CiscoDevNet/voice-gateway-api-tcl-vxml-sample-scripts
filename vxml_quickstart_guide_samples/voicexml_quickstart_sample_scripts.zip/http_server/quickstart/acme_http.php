<vxml version="2.0">

<!--
Cisco Voicexml Sample Code
File Name : acme_http.php

Copyright (c) 2003 by Cisco Systems, Inc.
All rights reserved.

SAMPLE APPLICATION AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND BY CISCO, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY FITNESS FOR A PARTICULAR PURPOSE, NONINFRINGEMENT, SATISFACTORY QUALITY OR ARISING FROM A COURSE OF
DEALING, LAW, USAGE, OR TRADE PRACTICE.  CISCO TAKES NO RESPONSIBILITY REGARDING ITS USAGE IN AN APPLICATION.  THE APPLICATION IS PROVIDED AS AN EXAMPLE
ONLY, THEREFORE CISCO DOES NOT MAKE ANY REPRESENTATIONS REGARDING ITS RELIABILITY, SERVICEABILITY, OR FUNCTION.  IN NO EVENT DOES CISCO WARRANT THAT THE
SOFTWARE IS ERROR FREE OR THAT CUSTOMER WILL BE ABLE TO OPERATE THE SOFTWARE WITHOUT PROBLEMS OR INTERRUPTIONS.  NOR DOES CISCO WARRANT THAT THE SOFTWARE
OR ANY EQUIPMENT ON WHICH THE SOFTWARE IS USED WILL BE FREE OF VULNERABILITY TO INTRUSION OR ATTACK.  THIS SAMPLE APPLICATION IS NOT SUPPORTED BY CISCO IN
ANY MANNER. CISCO DOES NOT ASSUME ANY LIABILITY ARISING FROM THE USE OF THE APPLICATION. FURTHERMORE, IN NO EVENT SHALL CISCO OR ITS SUPPLIERS BE LIABLE FOR
ANY INCIDENTAL OR CONSEQUENTIAL DAMAGES, LOST PROFITS, OR LOST DATA, OR ANY OTHER INDIRECT DAMAGES EVEN IF CISCO OR ITS SUPPLIERS HAVE BEEN INFORMED OF THE
POSSIBILITY THEREOF.

-->

<?php
   $audiofile="stream.au";
   $streamphp="http://HTTP-SERVER/quickstart/streamrec.php?audiofile=$audiofile";
   $recordedfile="http://HTTP-SERVER/quickstart/records/$audiofile";
   if(isset($getdigit)){
	if( $getdigit == 3 ) {
            $next_form="#http_recording";
	} else {
            $next_form="#goodbye";
	}
        echo("
          <form id=\"menuoption\">
	   <block>
             <log> User selected $getdigit </log>
             <prompt>
		<audio src=\"audio/busy.au\" caching=\"fast\"/>
	     </prompt>
    	     <goto next=\"$next_form\"/>
           </block>
           <catch event=\"error.com.cisco.media.resource.unavailable\">
           	<log> Media Server is down </log>
           </catch>
	   <catch event=\"error.badfetch\">
              <prompt>
                  <audio src=\"audio/technical.au\" caching=\"fast\"/>
              </prompt>
              <log> (acme.php) Catch Handler  ::  A bad fetch event occured</log>
           </catch>
          </form>

	  <form id=\"http_recording\">
	    <var name=\"mydur\"/>
	    <var name=\"myterm\"/>
	    <var name=\"mysiz\"/>
		<record name=\"recording\"
			type=\"audio/basic;codec=g711ulaw\"
			maxtime=\"60s\"
			cisco-dest=\"$streamphp\"
		        dtmfterm=\"true\">
		    <prompt>
			<audio src=\"audio/record.au\" caching=\"fast\"/>
		        <audio src=\"audio/beep.au\" caching=\"fast\"/>
		    </prompt>
		</record>
		<filled namelist=\"recording\">
		  <assign name=\"mydur\" expr=\"recording$.duration\"/>
	  	  <assign name=\"mysiz\" expr=\"recording$.size\"/>
		  <assign name=\"myterm\" expr=\"recording$.termchar\"/>
		  <cisco-puts>DURATION IS <cisco-putvar namelist=\"mydur\"/></cisco-puts>
	          <cisco-puts>SIZE IS <cisco-putvar namelist=\"mysiz\"/></cisco-puts>
	          <cisco-puts>TERMCHAR IS <cisco-putvar namelist=\"myterm\"/></cisco-puts>
    		</filled>
		<block>
		    <cisco-puts>Audio sent to streamrec.php servlet</cisco-puts>
		    <prompt><audio src=\"audio/processing.au\"/></prompt>
		    <prompt><audio src=\"audio/recorded.au\" caching=\"fast\"/></prompt>
	            <goto next=\"#goodbye\"/>
		</block>
	  </form>

          <form id=\"goodbye\">
            <block>
	      <prompt>
	        <audio src=\"audio/goodbye.au\" caching=\"fast\"/>
	      </prompt>
	      <exit/>
            </block>
          </form>
       ");
    } else {
       print("
          <form id=\"backToMain\">
            <property name=\"timeout\" value=\"5s\"/>

            <block>
              <log> No option available</log>
              <exit/>
            </block>
          </form>
       ");
    }
  ?>
</vxml>
